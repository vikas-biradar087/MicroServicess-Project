package com.api.gatewayy.ApiGatewayy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiGatewayyApplication.class, args);
	}

}
