package com.api.hotel.HotelServicee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelServiceeApplicationTests {

	@Test
	void contextLoads() {
	}

}
