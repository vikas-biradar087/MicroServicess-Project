package com.api.rating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatingServiceeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatingServiceeApplication.class, args);
	}

}
